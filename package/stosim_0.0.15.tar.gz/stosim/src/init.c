/*
tools::package_native_routine_registration_skeleton("C:/Rpack/stosim")
tools::package_native_routine_registration_skeleton("C:/_simdev/sim2")
*/
#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* FIXME: 
   Check these declarations against the C/Fortran source code.
*/

/* .Call calls */
extern SEXP AddWpush(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP AddOverlay(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP DetailOpLinesCPP(SEXP, SEXP, SEXP, SEXP);
extern SEXP MultiTrainWithInventoryCPP(SEXP, SEXP, SEXP, SEXP);
extern SEXP SimulationHistory(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);

static const R_CallMethodDef CallEntries[] = {
    {"AddWpush",                   (DL_FUNC) &AddWpush,                    8},
    {"AddOverlay",                 (DL_FUNC) &AddOverlay,                  8},
    {"DetailOpLinesCPP",           (DL_FUNC) &DetailOpLinesCPP,            4},
    {"MultiTrainWithInventoryCPP", (DL_FUNC) &MultiTrainWithInventoryCPP,  4},
    {"SimulationHistory",          (DL_FUNC) &SimulationHistory,          12},
    {NULL, NULL, 0}
};

void R_init_stosim(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
}


