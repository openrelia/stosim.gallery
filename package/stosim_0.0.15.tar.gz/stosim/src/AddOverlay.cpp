#include "stosim.h"


SEXP AddOverlay(SEXP arg1, SEXP arg2, SEXP arg3, SEXP arg4, SEXP arg5, SEXP arg6, SEXP arg7, SEXP arg8) {

// set dataframe arguments from R into Rcpp vector classes for use in C++
	Rcpp::NumericVector baseDurationVec(arg1);
	Rcpp::NumericVector baseOpLineVec(arg2);
	Rcpp::NumericVector baseEventIDVec(arg3);
	Rcpp::NumericVector baseTimeVec(arg4);
	Rcpp::NumericVector addDurationVec(arg5);
	Rcpp::NumericVector addOpLineVec(arg6);
	Rcpp::NumericVector addEventIDVec(arg7);
	Rcpp::NumericVector addTimeVec(arg8);

	Rcpp::NumericVector NSH_DurationVec;
	Rcpp::NumericVector NSH_OpLineVec;
	Rcpp::NumericVector NSH_EventIDVec;
	Rcpp::NumericVector NSH_TimeVec;



	double SimLimit=baseTimeVec[baseTimeVec.size()-1];
	double nowDuration = 0.0;

	int basePtr=0;
	int addPtr=0;

	double endLastEvent=0.0;

	do   {


// Most often case - just copy BaseHist record
		if(baseTimeVec[basePtr]<addTimeVec[addPtr])  {
// assure this is not inside an overlay event
		    if(baseTimeVec[basePtr]>endLastEvent)  {
//   newSimulationHistory<-rbind(newSimulationHistory,BaseHist[basePtr,])
			NSH_DurationVec.push_back(baseDurationVec[basePtr]);
			NSH_OpLineVec.push_back(baseOpLineVec[basePtr]);
			NSH_EventIDVec.push_back(baseEventIDVec[basePtr]);
			NSH_TimeVec.push_back(baseTimeVec[basePtr]);
		    endLastEvent=baseTimeVec[basePtr]+baseDurationVec[basePtr];
		    basePtr++;

			} else{
				if(baseTimeVec[basePtr]+baseDurationVec[basePtr]>endLastEvent)  {
// this is a rare event that extends beyond the overlay
				nowDuration=baseTimeVec[basePtr]+baseDurationVec[basePtr]-endLastEvent;
				NSH_DurationVec.push_back(nowDuration);
				NSH_OpLineVec.push_back(baseOpLineVec[basePtr]);
				NSH_EventIDVec.push_back(baseEventIDVec[basePtr]);
				NSH_TimeVec.push_back(endLastEvent);

				endLastEvent=endLastEvent+nowDuration;
				    basePtr++;
				}
    // if only this logical point is reached, then the event has simply been hidden by the overlay
			    basePtr++;
// endLastEvent does not change

		    }
		} else {
// Second most often case - this will be an overlay
// as long as it is not a duplicate
		    if(baseTimeVec[basePtr]>addTimeVec[addPtr])  {
        //newSimulationHistory<-rbind(newSimulationHistory,OverLayHist[addPtr,])
				NSH_DurationVec.push_back(addDurationVec[addPtr]);
				NSH_OpLineVec.push_back(addOpLineVec[addPtr]);
				NSH_EventIDVec.push_back(addEventIDVec[addPtr]);
				NSH_TimeVec.push_back(addTimeVec[addPtr]);
				endLastEvent=addTimeVec[addPtr]+addDurationVec[addPtr];
		        addPtr++;

			    } else{
    // The only possibility left is that base and add times are equal
    // most likely this is a duplicate CC event, like maintenance
    // but we must also test for the rare possiblity that two separate
    // events ended up with exactly the same time.

   // Test for identical Duration to establish this is a duplicate event
			    if(baseTimeVec[basePtr]==addTimeVec[addPtr])  {
//        newSimulationHistory<-rbind(newSimulationHistory,BaseHist[basePtr,])
					NSH_DurationVec.push_back(baseDurationVec[basePtr]);
					NSH_OpLineVec.push_back(baseOpLineVec[basePtr]);
					NSH_EventIDVec.push_back(baseEventIDVec[basePtr]);
					NSH_TimeVec.push_back(baseTimeVec[basePtr]);
					endLastEvent=baseTimeVec[basePtr]+baseDurationVec[basePtr];
					addPtr++;
					basePtr++;
				} else {
// this is an extremely rare event, this code may never be executed
// we will log only the longest duration event
					if(baseDurationVec[basePtr]>addDurationVec[addPtr])  {
   //     newSimulationHistory<-rbind(newSimulationHistory,BaseHist[basePtr,])
						NSH_DurationVec.push_back(baseDurationVec[basePtr]);
						NSH_OpLineVec.push_back(baseOpLineVec[basePtr]);
						NSH_EventIDVec.push_back(baseEventIDVec[basePtr]);
						NSH_TimeVec.push_back(baseTimeVec[basePtr]);
					    endLastEvent=baseTimeVec[basePtr]+baseDurationVec[basePtr];
					    addPtr++;
					    basePtr++;

					} else{
//        newSimulationHistory<-rbind(newSimulationHistory,OverLayHist[addPtr,])
						NSH_DurationVec.push_back(addDurationVec[addPtr]);
						NSH_OpLineVec.push_back(addOpLineVec[addPtr]);
						NSH_EventIDVec.push_back(addEventIDVec[addPtr]);
						NSH_TimeVec.push_back(addTimeVec[addPtr]);
						endLastEvent=addTimeVec[addPtr]+addDurationVec[addPtr];
						addPtr++;
						basePtr++;
					}

				}		//close the identical duration test block

		    }		// close the equal event times else block
		}		//close the final logic else block from original time comparisons
//while(endLastEvent<max(BaseHist[,baseTcol]) )  {
					//while (basePtr<3);

	}							//double SimLimit=baseTimeVec[baseTimeVec.size()-1];
	while(endLastEvent<SimLimit);	
	
	NSH_DurationVec.push_back(0.0);
	NSH_OpLineVec.push_back(-1);
	NSH_EventIDVec.push_back(-1);
	NSH_TimeVec.push_back(SimLimit);

	if(NSH_TimeVec(NSH_TimeVec.size()-1)+NSH_DurationVec(NSH_DurationVec.size()-1) > SimLimit)  {
		NSH_DurationVec(NSH_DurationVec.size()-1)=SimLimit-NSH_TimeVec(NSH_TimeVec.size()-1);
	}

//  Need to assemble the export newSimHistory dataframe from the NSH vectors for return

	Rcpp::DataFrame SimHistory=
	  Rcpp::DataFrame::create( Rcpp::Named("Time")=NSH_TimeVec,
		 Rcpp::Named("Duration")=NSH_DurationVec,
		 Rcpp::Named("OpLine")=NSH_OpLineVec,
		 Rcpp::Named("EventID")=NSH_EventIDVec);


return SimHistory;
}
