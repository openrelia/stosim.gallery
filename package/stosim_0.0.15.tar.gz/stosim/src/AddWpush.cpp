
#include "stosim.h"


 SEXP AddWpush(SEXP arg1, SEXP arg2, SEXP arg3,
      SEXP arg4,  SEXP arg5, SEXP arg6,
        SEXP arg7,  SEXP arg8)

{     using namespace Rcpp;
			// set dataframe arguments from R into Rcpp vector classes for use in C++

	Rcpp::NumericVector baseDurationVec(arg1);
	Rcpp::NumericVector baseOpLineVec(arg2);
	Rcpp::NumericVector baseEventIDVec(arg3);
	Rcpp::NumericVector baseTimeVec(arg4);
	Rcpp::NumericVector addDurationVec(arg5);
	Rcpp::NumericVector addOpLineVec(arg6);
	Rcpp::NumericVector addEventIDVec(arg7);
	Rcpp::NumericVector addTimeVec(arg8);

	Rcpp::NumericVector NSH_DurationVec;
	Rcpp::NumericVector NSH_OpLineVec;
	Rcpp::NumericVector NSH_EventIDVec;
	Rcpp::NumericVector NSH_TimeVec;




			// will need to identify and store the SimulationLimit from the baseTimeVec, before it is altered
	double SimLimit=baseTimeVec[baseTimeVec.size()-1];
	double add_duration=0.0;
			// n is the baseEventTimePtr
			//int baseEventTimePtr=0;
	int addEventTimePtr=0;
	int n=0;


do   {

	if(baseTimeVec[n]<addTimeVec[addEventTimePtr]) {

	NSH_DurationVec.push_back(baseDurationVec[n]);
	NSH_OpLineVec.push_back(baseOpLineVec[n]);
	NSH_EventIDVec.push_back(baseEventIDVec[n]);
	NSH_TimeVec.push_back(baseTimeVec[n]);




			//anything else that needs to be set before returning to loop?
			// increment n here
	n++;

	} else {
	add_duration=addDurationVec[addEventTimePtr];
	NSH_DurationVec.push_back(add_duration);
	NSH_OpLineVec.push_back(addOpLineVec[addEventTimePtr]);
	NSH_EventIDVec.push_back(addEventIDVec[addEventTimePtr]);
	NSH_TimeVec.push_back(addTimeVec[addEventTimePtr]);

			// now this is the "push" function, it probably should have been implemented as an stl transform
	for(int index=n; index<baseTimeVec.size()-1; index++)  {
	baseTimeVec[index]=baseTimeVec[index]+add_duration;
	}


			// increment the addEventTimePtr
	addEventTimePtr++;

	}
}
while(baseTimeVec[n]<SimLimit||addTimeVec[addEventTimePtr]<SimLimit);

	NSH_DurationVec.push_back(0.0);
	NSH_OpLineVec.push_back(-1);
	NSH_EventIDVec.push_back(-1);
	NSH_TimeVec.push_back(SimLimit);

	if(NSH_TimeVec(NSH_TimeVec.size()-1)+NSH_DurationVec(NSH_DurationVec.size()-1) > SimLimit)  {
	NSH_DurationVec(NSH_DurationVec.size()-1)=SimLimit-NSH_TimeVec(NSH_TimeVec.size()-1);
	}



//  Need to assemble the export newSimHistory dataframe from the NSH vectors for return

	Rcpp::DataFrame SimHistory=
	  Rcpp::DataFrame::create( Rcpp::Named("Time")=NSH_TimeVec,
		 Rcpp::Named("Duration")=NSH_DurationVec,
		 Rcpp::Named("OpLine")=NSH_OpLineVec,
		 Rcpp::Named("EventID")=NSH_EventIDVec);


	return SimHistory;


 }
