addOverlay<-function(BaseHist,OverLayHist)  {									
									
	## validate input dataframes are SimHistories of Type1 Model								
	Type1_sh_Names<-c("Page","Time","Duration","OpLine","EventID")							
									
	Input_Names<-names(BaseHist)								
	if(length(Input_Names)!=length(Type1_sh_Names))  {								
	stop("Error in stosim:    incorrect input BaseHist length to SimHistory") 								
	} else {								
	for(n in 1:length(Type1_sh_Names)) {								
	if(Input_Names[n]!=Type1_sh_Names[n]) stop("Error in stosim:   input BaseHist is not SimHistory") }								
	}								
									
	Input_Names<-names(OverLayHist)								
	if(length(Input_Names)!=length(Type1_sh_Names))  {								
	stop("Error in stosim:    incorrect input OverLayHist length to SimHistory") 								
	} else {								
	for(n in 1:length(Type1_sh_Names)) {								
	if(Input_Names[n]!=Type1_sh_Names[n]) stop("Error in stosim:   input BaseHist is not SimHistory") }								
	}								

	BasePages<-BaseHist$Page[length(BaseHist$Page)]
	OverLayPages<-OverLayHist$Page[length(OverLayHist$Page)]
	if(BasePages != OverLayPages) stop("input histories have different number of pages")

	BaseHrsPerPage<-BaseHist$Time[length(BaseHist$Time)]
	OverLayHrsPerPage<-OverLayHist$Time[length(OverLayHist$Time)]
	if(BaseHrsPerPage != OverLayHrsPerPage) stop("input histories have different simulation years")
	
	OutputDF<-NULL

	for(p in 1:BasePages)  {

		BasePage<- BaseHist[which(BaseHist$Page== p),]
		OverLayPage<-OverLayHist[which(OverLayHist$Page== p),]


		## Extract vectors to pass to Rcpp
		baseTimeVec<-BasePage[,2]
		baseDurationVec<-BasePage[,3]
		baseOpLineVec<-BasePage[,4]
		baseEventIDVec<-BasePage[,5]

		addTimeVec<-OverLayPage[,2]
		addDurationVec<-OverLayPage[,3]
		addOpLineVec<-OverLayPage[,4]
		addEventIDVec<-OverLayPage[,5]

		 ## this is the old call to the unregistered C++ code in the stosim library
#		RcppDF<-.Call("AddOverlay", baseDurationVec, baseOpLineVec, baseEventIDVec, baseTimeVec,
#			addDurationVec, addOpLineVec, addEventIDVec, addTimeVec, PACKAGE="stosim")

		RcppDF<-.Call(AddOverlay, baseDurationVec, baseOpLineVec, baseEventIDVec, baseTimeVec,
			addDurationVec, addOpLineVec, addEventIDVec, addTimeVec)


		## after the call a page column has to be added back
		Page<-rep(p,length(RcppDF[,1]))
		PageCol<-data.frame(Page)
		RcppDF<-cbind(PageCol,RcppDF)
		
		OutputDF<-rbind(OutputDF,RcppDF)
	}

OutputDF
}

