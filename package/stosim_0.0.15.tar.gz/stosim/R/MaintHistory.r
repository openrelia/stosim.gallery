MaintHistory<-function(Interval,Duration,FirstInterval=0,SimulationYears = 2000,SimulationYearsPerPage = 1000)  {


Pages=as.integer(SimulationYears/SimulationYearsPerPage)
if(Pages<1) {
stop("Error in stosim:  SimulationYears are less than SimulationYearsPerPage")
}

if(SimulationYearsPerPage>2000)  {
stop("Error in stosim:  Accuracy lost over 2000 years per page")
}


OutDF<-NULL
## the main loop through pages
for(p in 1:Pages)  {

LastTime= 0
EventID=100
## Initialize a maintenance event dataframe with a first entry
if(FirstInterval>0) {
Time=LastTime+FirstInterval
MaintenanceHistory<-data.frame("Page"=p, "Time"=Time, "Duration"=Duration,"OpLine"=1,"EventID"=EventID)
LastTime=Time+Duration
} else {
Time=LastTime+Interval
MaintenanceHistory<-data.frame("Page"=p, "Time"=Time, "Duration"=Duration,"OpLine"=1,"EventID"=EventID)
LastTime=Time+Duration
}

while((LastTime+Interval)<(SimulationYearsPerPage*8760)) {

Time=LastTime+Interval
tempRow<-data.frame("Page"=p, "Time"=Time, "Duration"=Duration,"OpLine"=1,"EventID"=EventID)
MaintenanceHistory<-rbind(MaintenanceHistory,tempRow)

LastTime=Time+Duration

}

Duration=0
OpLine=0
EventID=0
Time=SimulationYearsPerPage*8760
tempRow<-data.frame("Page"=p, Time, Duration, OpLine, EventID)
MaintenanceHistory<-rbind(MaintenanceHistory,tempRow)

OutDF<-rbind(OutDF, MaintenanceHistory)
}

OutDF
}
